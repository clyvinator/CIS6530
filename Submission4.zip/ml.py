import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report, confusion_matrix

def count_ngrams(documents, ngram_range=(1, 1)):
    vocabulary = Counter()
    feature_matrix = []

    for doc in documents:
        ngram_counts = Counter()
        words = doc.split()
        
        for n in range(ngram_range[0], ngram_range[1] + 1):
            ngrams = [' '.join(words[i:i + n]) for i in range(len(words) - n + 1)]
            ngram_counts.update(ngrams)
        
        feature_matrix.append(ngram_counts)
        vocabulary.update(ngram_counts)
    
    vocab_list = sorted(vocabulary.keys())
    matrix = [[doc.get(ngram, 0) for ngram in vocab_list] for doc in feature_matrix]

    return matrix, vocab_list

df = pd.read_csv("output_opcodes.csv")

documents = df['Opcodes'] 

feature_matrix, vocab_list = count_ngrams(documents, ngram_range=(1, 2))
X = np.array(feature_matrix)
print("Feature Matrix Shape:", X.shape)

# Normalize the data to range [0, 1]
scaler = MinMaxScaler()
X_normalized = scaler.fit_transform(X)  

# Extract target labels
y = df['APT']

X_train, X_test, y_train, y_test = train_test_split(X_normalized, y, test_size=0.3, random_state=42)



# SVM
svm = SVC()
svm.fit(X_train, y_train)
y_pred_svm = svm.predict(X_test)
cm_svm = confusion_matrix(y_test, y_pred_svm)

print("SVM Performance:")
print(classification_report(y_test, y_pred_svm, zero_division=0))
print("Confusion Matrix:\n", cm_svm)
accuracy_svm = accuracy_score(y_test, y_pred_svm)
print(f"SVM Accuracy: {accuracy_svm}")

# KNN (k=3)
knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train, y_train)
y_pred_knn = knn.predict(X_test)
cm_knn = confusion_matrix(y_test, y_pred_knn)

print("\nKNN Performance:")
print(classification_report(y_test, y_pred_knn, zero_division=0))
print("Confusion Matrix:\n", cm_knn)
accuracy_knn = accuracy_score(y_test, y_pred_knn)
print(f"KNN Accuracy: {accuracy_knn}")

# Decision Tree
dt = DecisionTreeClassifier()
dt.fit(X_train, y_train)
y_pred_dt = dt.predict(X_test)
cm_dt = confusion_matrix(y_test, y_pred_dt)

print("\nDecision Tree Performance:")
print(classification_report(y_test, y_pred_dt, zero_division=0))
print("Confusion Matrix:\n", cm_dt)
accuracy_dt = accuracy_score(y_test, y_pred_dt)
print(f"Decision Tree Accuracy: {accuracy_dt}")



fig, axes = plt.subplots(1, 3, figsize=(15, 5))

# SVM Confusion Matrix
sns.heatmap(cm_svm, annot=True, fmt='d', cmap='Blues', ax=axes[0], cbar=False)
axes[0].set_title("SVM Confusion Matrix")
axes[0].set_xlabel('Predicted')
axes[0].set_ylabel('True')

# KNN Confusion Matrix
sns.heatmap(cm_knn, annot=True, fmt='d', cmap='Blues', ax=axes[1], cbar=False)
axes[1].set_title("KNN Confusion Matrix")
axes[1].set_xlabel('Predicted')
axes[1].set_ylabel('True')

# Decision Tree Confusion Matrix
sns.heatmap(cm_dt, annot=True, fmt='d', cmap='Blues', ax=axes[2], cbar=False)
axes[2].set_title("Decision Tree Confusion Matrix")
axes[2].set_xlabel('Predicted')
axes[2].set_ylabel('True')

plt.tight_layout()
plt.show()



accuracies = [accuracy_svm, accuracy_knn, accuracy_dt]
classifiers = ['SVM', 'KNN', 'Decision Tree']

# Accuracy Comparison
plt.figure(figsize=(8, 6))
plt.bar(classifiers, accuracies, color=['teal', 'purple', 'orange'])
plt.title('Classifier Accuracy Comparison')
plt.ylabel('Accuracy')
plt.ylim([0, 1])
plt.show()