import os
import csv
import pandas as pd

def preprocess_opcodes_nested(folder_path, output_csv):
    data_rows = []

    # Traverse each subfolder (APT group)
    for subfolder in os.listdir(folder_path):
        subfolder_path = os.path.join(folder_path, subfolder)
        if os.path.isdir(subfolder_path): 
            apt_group = subfolder
            
            # Traverse each file in the APT group folder
            for file_name in os.listdir(subfolder_path):
                file_path = os.path.join(subfolder_path, file_name)
                
                if os.path.isfile(file_path): 
                    try:
                        # Read opcodes from the file
                        with open(file_path, "r") as file:
                            opcodes = file.read().splitlines() 
                        
                        opcode_string = ", ".join(opcodes)
                        if(len(opcode_string.strip()) > 0 and opcode_string.strip().count(',') > 0):
                            data_rows.append([opcode_string, apt_group])
                        else:
                            print("Length zero for APT GROUP or INVALID VALUE" + apt_group)
                    
                    except Exception as e:
                        print(f"Error processing file {file_name} in {subfolder}: {e}")
    
   # Write data to a temporary CSV file
    temp_csv = "temp_output.csv"
    try:
        with open(temp_csv, "w", newline="", encoding="utf-8") as csvfile:
            writer = csv.writer(csvfile)
            # Write header
            writer.writerow(["Opcodes", "APT"])
            # Write rows
            writer.writerows(data_rows)
    except Exception as e:
        print(f"Error writing temporary CSV file: {e}")

    # Remove duplicate rows
    try:
        df = pd.read_csv(temp_csv)
        df_deduplicated = df.drop_duplicates()
        df_deduplicated.to_csv(output_csv, index=False)
        print(f"Deduplicated CSV saved to: {output_csv}")
    except Exception as e:
        print(f"Error processing deduplication: {e}")

root_folder = "./OpCodes"  
output_csv = "output_opcodes.csv"  

# Run the preprocessing
preprocess_opcodes_nested(root_folder, output_csv)
