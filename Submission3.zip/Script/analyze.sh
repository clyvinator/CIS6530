#!/bin/bash
#authors: Rohini Prabakaran and Clyde Shelton Bangera
#group 9
#MCTI CIS6530 Submission 3

# Path to Ghidra directory
GHIDRA_DIR=/mnt/c/Users/Win10/Downloads/ghidra_11.2_PUBLIC_20240926/ghidra_11.2_PUBLIC

# Python script file
SCRIPT_NAME=extract_opcodes.py

# Ghidra project directory
PROJECT_DIR=/mnt/c/Users/Win10/Desktop/ghidra_projects

# Directory of malware samples
MALWARE_DIR=/mnt/c/Users/Win10/Desktop/test_malware

# Loop over all malware files in the malware directory
find "$MALWARE_DIR" -mindepth 2 -type f | while read -r malware; do
    # Extract the base name of the malware file
    PROJECT_NAME=$(basename "$malware")
    
    # Create a subdirectory in Ghidra projects based on the APT group folder name
    APT_GROUP=$(basename "$(dirname "$malware")")

    PROJECT_PATH="$PROJECT_DIR/$APT_GROUP/$PROJECT_NAME"

    # Ensure the directory structure exists
    mkdir -p "$PROJECT_PATH"
    
    # Run Ghidra in headless mode to analyze and extract opcodes
    "$GHIDRA_DIR/support/analyzeHeadless" "$PROJECT_PATH" "$PROJECT_NAME" -import "$malware" -postScript "$SCRIPT_NAME" "$APT_GROUP"
done