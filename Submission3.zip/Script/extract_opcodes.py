#authors: Rohini Prabakaran and Clyde Shelton Bangera
#group 9
#MCTI CIS6530 Submission 3
#references code from https://ghidra.re/ghidra_docs/api/

import os

try:
    # Get the current program (the binary being analyzed)
    currentProgram = getCurrentProgram() # type: ignore
    binary_name = currentProgram.getName()

    # Listing object represents all the code
    listing = currentProgram.getListing()

    script_args = getScriptArgs() # type: ignore

    # Get name of APT group for creating directory
    apt_group_name = script_args[0]
    
    output_file_path = "/mnt/c/Users/Win10/Desktop/output/" + apt_group_name
    if not os.path.exists(output_file_path):
        os.makedirs(output_file_path) # Create directory for APT if it doesn't exist
    output_file_path += "/" + binary_name + "_opcodes.txt"
    with open(output_file_path, "w") as f:
        # Iterate over all instructions in the program
        instructions = listing.getInstructions(True)
        
        for instruction in instructions:
            opcode = instruction.getMnemonicString()
            
            # Write the address and the opcode bytes to the file
            f.write("{}\n".format(opcode))

    print("Opcodes extracted to {}.".format(output_file_path))
    print("***\n\n\n***")

except Exception as e:
    print("Exception Occured, Moving On To Next Malware")
    print(e)